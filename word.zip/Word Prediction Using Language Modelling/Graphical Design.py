from tkinter import filedialog
from tkinter import *




def mysubmit():
  root.filename =  filedialog.askopenfile(initialdir = "/",title = "Select file",filetypes = (("Text files","*.txt"),("all files","*.*")))
  print (root.filename)
    
root = Tk()
myframe = Frame(root,height=500,width=500)

location=IntVar()
gram=IntVar()




inputLabel = Label(myframe,text="Input:",bg="cyan",fg="black")
inputEntry = Entry(myframe,bg="blue",fg="white")

lengthLabel = Label(myframe,text="Length:",bg="cyan",fg="black")
lengthEntry = Entry(myframe,bg="blue",fg="white")

LocationLabel = Label(myframe,text="Choose Location :",bg="cyan",fg="black")
start =  Radiobutton(myframe, text="start", variable=location, value=1)
middle = Radiobutton(myframe, text="middle" , variable=location, value=2)
end =    Radiobutton(myframe, text="end", variable=location, value=3)

GramLabel = Label(myframe,text="Choose technic :",bg="cyan",fg="black")
Unigram = Radiobutton(myframe, text="Unigram", variable=gram, value=1)
Bigram =  Radiobutton(myframe, text="bigram" , variable=gram, value=2)
Trigram = Radiobutton(myframe, text="Trigram", variable=gram, value=3)

submit = Button(myframe,text="Submit",bg="cyan",fg="black",command=mysubmit)


ResultLabel = Label(myframe,text="Result:",bg="cyan",fg="black",height=10,width=40)

myframe.grid(padx=200, pady=50)

inputLabel.grid(row=1,column=1) 
inputEntry.grid(row=1,column=2)  

lengthLabel.grid(row=3,column=1) 
lengthEntry.grid(row=3,column=2) 

LocationLabel.grid(row=5,column=1) 
start.grid(row=6,column=2)  
middle.grid(row=7,column=2) 
end.grid(row=8,column=2) 

GramLabel.grid(row=10,column=1) 
Unigram.grid(row=11,column=2)  
Bigram.grid(row=12,column=2) 
Trigram.grid(row=13,column=2)

submit.grid(row=20,column=2)
ResultLabel.grid(row=23,column=2)

root.mainloop()
