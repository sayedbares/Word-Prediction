import re
import operator
import math
from tkinter import *
from tkinter import filedialog

filename = "inputs/dataset1.txt"
def pos():
  global filename
  filename=  filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("Text files","*.txt"),("all files","*.*")))
  

    

def TextRecognizer():
    with open(filename,"r",encoding="ascii", errors="ignore") as rfile:
        infile = rfile.readlines()
    sent=[]
    for i in range (len(infile)):
         sent.extend([s for s in infile[i].replace(',',' ').replace('.',' ').splitlines()])
    sent=' '.join(sent)
   
    

   
    
    unigram=[]
    bigram=[]
    trigram=[]
    
    unifreq={}
    bifreq={}
    trifreq={}
    
    uniprob={}
    biprob={}
    triprob={}
    
    # to get n-grams

    for i in range(len(sent.split())-1):
            unigram.append(sent.split()[i])
            bigram.append(sent.split()[i]+" "+sent.split()[i+1])
            if i<len(sent.split())-2:
                trigram.append(sent.split()[i]+" "+sent.split()[i+1]+" "+sent.split()[i+2])
            if i==len(sent.split())-2:
                unigram.append(sent.split()[i+1])

                
  # to find frequency of n-grams
    for p in unigram:
        found=False
        for j in unifreq:
           if j==p:
            unifreq[j]+=1
            found=True
        if found==False:
          unifreq.update({p:1})
    
    for p in bigram:
        found=False
        for j in bifreq:
           if j==p:
            bifreq[j]+=1
            found=True
        if found==False:
          bifreq.update({p:1})
     
    for p in trigram:
        found=False
        for j in trifreq:
           if j==p:
            trifreq[j]+=1
            found=True
        if found==False:
          trifreq.update({p:1})


    
    # to find the types and tokens of each n-grams
    
    typeUnigram = len(unifreq)
    tokenUnigram = 0
    for uni in unifreq:
        tokenUnigram += unifreq[uni]

    typeBigram = len(bifreq)
    tokenBigram = 0
    for bi in bifreq:
        tokenBigram += bifreq[bi]

    typeTrigram = len(trifreq)
    tokenTrigram = 0
    for ti in trifreq:
        tokenTrigram += trifreq[ti]


    # to assign probability to n-grams

    for uni in unifreq:
        uniprob.update({uni:round(unifreq[uni]/tokenUnigram,6)})
    
    for bi in bifreq:
        FirstWord = bi.split()[0]
        propability = round(bifreq[bi]/unifreq[FirstWord],6)
        biprob.update({bi:propability})

    for ti in trifreq:
        FandSWord = ti.split()[0]+' '+ti.split()[1]
        propability = round(trifreq[ti]/bifreq[FandSWord],6)
        triprob.update({ti:propability})



    # to sort the n-grams based on probability
        
    
    sorted_uniprob = sorted(uniprob.items(), key=operator.itemgetter(1), reverse=True)
    sorted_biprob = sorted(biprob.items(), key=operator.itemgetter(1), reverse=True)
    sorted_triprob = sorted(triprob.items(), key=operator.itemgetter(1), reverse=True)

    with open('1.Unigram.txt','w') as o:
      for grams in sorted_uniprob:
            o.write(str(grams)+"\n")
    with open('2.Bigram.txt','w') as o:
      for grams in sorted_biprob:
            o.write(str(grams)+"\n")
    with open('3.Trigram.txt','w') as o:
      for grams in sorted_triprob:
            o.write(str(grams)+"\n")
    


    #to find the sentence based on n-grams
    
    example=inputEntry.get()
    lenght=int(lengthEntry.get())
    gram=int(ngram.get())
    
    if gram==1:
         answer=[]
         first=[]
         second=[]
         search=example.split()[-1]
         product=1
         answer.append(example)
         paviot=0
         reverser=False
         
         for j in range(len(sorted_uniprob)):
                 if location.get()==1:
                    if sorted_uniprob[j][0]==search:
                      paviot=j
                      del answer[0]
                      for i in range (lenght+1):
                         try:
                           answer.append(str(sorted_uniprob[paviot][0]))
                         except IndexError:
                           break
                         product*=sorted_uniprob[paviot][1]
                         search=sorted_uniprob[paviot][0]
                         paviot=paviot+1
                      break
                        
                      


                    
                 elif location.get()==2:
                    if sorted_uniprob[j][0]==search:
                      paviot=j
                      del answer[0]
                      
        
                      for i in range (int((lenght)/2)):
                         paviot=paviot-1
                         try:
                          first.append(str(sorted_uniprob[paviot][0]))
                         except IndexError:
                           break
                         product*=sorted_uniprob[paviot][1]
                         search=sorted_uniprob[paviot][0]
                      first.reverse()
                      paviot=j+1

                      
                      
                      
                      for i in range ((int((lenght)/2)),lenght):
                         try:
                          second.append(str(sorted_uniprob[paviot][0]))
                         except IndexError:
                           break
                         product*=sorted_uniprob[paviot][1]
                         search=sorted_uniprob[paviot][0]
                         paviot=paviot+1
                      answer.extend(first)
                      answer.append(example.split()[-1])
                      answer.extend(second)
                      break

                    
                 elif location.get()==3:
                    if sorted_uniprob[j][0]==search:
                      paviot=j
                      del answer[0]
                      for i in range (lenght+1):
                         try:
                          answer.append(str(sorted_uniprob[paviot][0]))
                         except IndexError:
                           break
                         product*=sorted_uniprob[paviot][1]
                         search=sorted_uniprob[paviot][0]
                         paviot=paviot-1
                      answer.reverse()
                      break
                    
 
             
         ResultLabel.config(text=((' '.join(answer)+"    "+str(product)+" %")))
        




    if gram==2:
         answer=[]
         first=[]
         second=[]
         search=example.split()[-1]
         product=1
         answer.append(search)
         reverser=False
        
         for j in range (lenght):
             for word in sorted_biprob:
                 if location.get()==1:
                    if word[0].split()[0]==search:
                         answer.append(str(word[0].split()[1]))
                         product*=word[1]
                         search=word[0].split()[1]
                         break
                          
                 elif location.get()==2:
                     if j<(lenght-1)/2:
                       if word[0].split()[1]==search:
                           first.append(str(word[0].split()[0]))
                           product*=word[1]
                           search=word[0].split()[0]
                           break
                
                        
                     elif j>lenght/2:
                       if word[0].split()[0]==search :
                         second.append(str(word[0].split()[1]))
                         product*=word[1]
                         search=word[0].split()[1]
                         break
                        
                         

                 elif location.get()==3:
                    if word[0].split()[1]==search:
                         answer.append(str(word[0].split()[0]))
                         product*=word[1]
                         search=word[0].split()[0]
                         reverser=True
                         break
        

         if reverser==True:
             answer.reverse()
         if location.get()==2:
             del answer[0:]
             first.reverse()
             answer.extend(first)
             answer.append(example.split()[-1])
             answer.extend(second)
             
         ResultLabel.config(text=((' '.join(answer)+"    "+str(product)+" %")))
        




    if gram==3:
      if len(example.split())<2:
         ResultLabel.config(text="Error: For Trigram at least two input")
         
      else:
         answer=[]
         first=[]
         second=[]
         search=(example.split()[-2])+' '+(example.split()[-1])
         product=1
         answer.append(example)
         reverser=False
        
         for j in range (lenght):
            if location.get()==1:
              for word in sorted_triprob:
                    if word[0].split()[0]==search.split()[0] and word[0].split()[1]==search.split()[1]:
                         answer.append(str(word[0].split()[2]))
                         product*=word[1]
                         search=(word[0].split()[1])+' '+(word[0].split()[2])
                         break
            elif location.get()==2:
               if j<(lenght-1)/2:
                 for word in sorted_triprob:
                       if word[0].split()[1]==search.split()[0] and word[0].split()[2]==search.split()[1]:
                           first.append(str(word[0].split()[0]))
                           product*=word[1]
                           search=(word[0].split()[0])+' '+(word[0].split()[1])
                           break
               elif j == (lenght-1)/2:
                 search=(example.split()[-2])+' '+(example.split()[-1])
               elif j>lenght/2:
                 for word in sorted_triprob:
                   if word[0].split()[0]==search.split()[0] and word[0].split()[1]==search.split()[1]:
                           second.append(str(word[0].split()[2]))
                           product*=word[1]
                           search=(word[0].split()[1])+' '+(word[0].split()[2])
                           break
              
            elif location.get()==3:
              for word in sorted_triprob:
                    if word[0].split()[1]==search.split()[0] and word[0].split()[2]==search.split()[1]:
                         answer.append(str(word[0].split()[0]))
                         product*=word[1]
                         search=(word[0].split()[0])+' '+(word[0].split()[1])
                         break

         if location.get()==3:
           answer.reverse()
         elif location.get()==2:
           del answer[0:]
           first.reverse()
           answer.extend(first)
           answer.append(str(example.split()[-2])+' '+(example.split()[-1]))
           answer.extend(second)
         
            
         ResultLabel.config(text=((' '.join(answer)+"    "+str(product)+" %")))

       

    
root = Tk()
myframe = Frame(root,height=500,width=500)

location=IntVar()
ngram=IntVar()

inputLabel = Label(myframe,text="Input:",bg="cyan",fg="black")
inputEntry = Entry(myframe,bg="green",fg="white")

lengthLabel = Label(myframe,text="Length:",bg="cyan",fg="black")
lengthEntry = Entry(myframe,bg="green",fg="white")

possition = Button(myframe,text="Choose file",bg="cyan",fg="black",command=pos)


LocationLabel = Label(myframe,text="Choose Location :",bg="cyan",fg="black")
start =  Radiobutton(myframe, text="start", variable=location, value=1)
middle = Radiobutton(myframe, text="middle" , variable=location, value=2)
end =    Radiobutton(myframe, text="end", variable=location, value=3)


GramLabel = Label(myframe,text="Choose technic :",bg="cyan",fg="black")
Unigram = Radiobutton(myframe, text="Unigram", variable=ngram, value=1)
Bigram =  Radiobutton(myframe, text="bigram" , variable=ngram, value=2)
Trigram = Radiobutton(myframe, text="Trigram", variable=ngram, value=3)

submit = Button(myframe,text="Submit",bg="cyan",fg="black",command=TextRecognizer)


ResultLabel = Label(myframe,text="Result:",bg="cyan",fg="black",height=10,width=100)

myframe.grid(padx=200, pady=50)

inputLabel.grid(row=1,column=1) 
inputEntry.grid(row=1,column=2)  

lengthLabel.grid(row=3,column=1) 
lengthEntry.grid(row=3,column=2)

possition.grid(row=4,column=2,columnspan=2)

LocationLabel.grid(row=5,column=1) 
start.grid(row=6,column=2)  
middle.grid(row=7,column=2) 
end.grid(row=8,column=2) 

GramLabel.grid(row=10,column=1) 
Unigram.grid(row=11,column=2)  
Bigram.grid(row=12,column=2) 
Trigram.grid(row=13,column=2)

submit.grid(row=20,column=2)
ResultLabel.grid(row=23,column=2)

root.mainloop()




    
        
    

            
